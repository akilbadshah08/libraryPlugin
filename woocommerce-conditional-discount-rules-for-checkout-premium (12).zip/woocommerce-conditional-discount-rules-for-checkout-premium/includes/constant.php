<?php
/**
 * define constant variables
 * define admin side constant
 *
 * @since  1.0.0
 * @author Multidots
 *
 * @param null
 */

// define constant for plugin slug
define( 'WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_PLUGIN_NAME', 'Conditional Discount Rules For WooCommerce Checkout Pro' );
define( 'WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_FREE_PLUGIN_NAME', 'Conditional Discount Rules For WooCommerce Checkout' );
define( 'WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_VERSION_NAME', 'Premium Version ' );
define( 'WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_FREE_VERSION_NAME', 'Free Version ' );
define( 'WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN', 'woo-conditional-discount-rules-for-checkout' );