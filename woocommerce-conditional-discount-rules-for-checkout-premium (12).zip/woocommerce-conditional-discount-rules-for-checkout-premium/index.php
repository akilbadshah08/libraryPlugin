<?php // Silence is golden
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}