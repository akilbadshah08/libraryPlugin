<?php

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<?php require_once(plugin_dir_path( __FILE__ ).'header/plugin-header.php' ); ?>
<?php
$submitFee=filter_input(INPUT_POST,'submitFee',FILTER_SANITIZE_STRING);
if ( isset($submitFee ) && ! empty( $submitFee ) ) {
	$post_data = filter_input_array(INPUT_POST, 
		array(
		    'post_type' =>FILTER_SANITIZE_STRING,
		    'dpad_post_id' =>FILTER_SANITIZE_STRING,
		    'dpad_settings_product_dpad_title' =>FILTER_SANITIZE_STRING,
		    'dpad_settings_select_dpad_type' =>FILTER_SANITIZE_STRING,
		    'dpad_settings_product_cost' =>FILTER_SANITIZE_STRING,
		    'dpad_chk_qty_price' =>FILTER_SANITIZE_STRING,
		    'dpad_per_qty' =>FILTER_SANITIZE_STRING,
		    'extra_product_cost' =>FILTER_SANITIZE_STRING,
		    'dpad_settings_start_date' =>FILTER_SANITIZE_STRING,
		    'dpad_settings_end_date' =>FILTER_SANITIZE_STRING,
		    'dpad_settings_status' =>FILTER_SANITIZE_STRING,
		    'total_row' =>FILTER_SANITIZE_STRING,
		    'submitFee' =>FILTER_SANITIZE_STRING,
		)

	);
	$post_data['dpad']=filter_input(INPUT_POST,  'dpad',FILTER_SANITIZE_STRING,FILTER_REQUIRE_ARRAY);
	$post_data['condition_key']=filter_input(INPUT_POST,  'condition_key',FILTER_SANITIZE_STRING,FILTER_REQUIRE_ARRAY);
	$this->wdpad_pro_dpad_conditions_save( $post_data );
}
$paction=filter_input(INPUT_GET,'action',FILTER_SANITIZE_STRING);
$paction_id=filter_input(INPUT_GET,'id',FILTER_SANITIZE_STRING);
if ( isset( $paction ) && $paction === 'edit' ) {
	$btnValue          = __( 'Update', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN );
	$dpad_title        = __( get_the_title( $paction_id ), WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN );
	$getFeesCost       = __( get_post_meta( $paction_id, 'dpad_settings_product_cost', true ), WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN );
	$getFeesPerQtyFlag = get_post_meta( $paction_id, 'dpad_chk_qty_price', true );
	$getFeesPerQty     = get_post_meta( $paction_id, 'dpad_per_qty', true );
	$extraProductCost  = get_post_meta( $paction_id, 'extra_product_cost', true );
	$getFeesType       = __( get_post_meta( $paction_id, 'dpad_settings_select_dpad_type', true ), WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN );
	$getFeesStartDate  = get_post_meta( $paction_id, 'dpad_settings_start_date', true );
	$getFeesEndDate    = get_post_meta( $paction_id, 'dpad_settings_end_date', true );
	$getFeesStatus     = get_post_meta( $paction_id, 'dpad_settings_status', true );
	$productFeesArray  = get_post_meta( $paction_id, 'dynamic_pricing_metabox', true );
	$getFeesOptional   = __( get_post_meta( $paction_id, 'dpad_settings_optional_gift', true ), WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN );
	$byDefaultChecked  = get_post_meta( $paction_id, 'by_default_checkbox_checked', true );
} else {
	$paction_id           = '';
	$btnValue          = __( 'Submit', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN );
	$dpad_title        = '';
	$getFeesCost       = '';
	$getFeesPerQtyFlag = '';
	$getFeesPerQty     = '';
	$extraProductCost  = '';
	$getFeesType       = '';
	$getFeesStartDate  = '';
	$getFeesEndDate    = '';
	$getFeesStatus     = '';
	$productFeesArray  = array();
	$getFeesOptional   = '';
	$byDefaultChecked  = '';
}
if ( $getFeesOptional === 'yes' ) {
	$style_display = 'display:block;';
} else {
	$style_display = 'display:none;';
}
?>
	<div class="text-condtion-is" style="display:none;">
		<select class="text-condition">
			<option value="is_equal_to"><?php esc_html_e( 'Equal to ( = )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
			<option value="less_equal_to"><?php esc_html_e( 'Less or Equal to ( <= )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
			<option value="less_then"><?php esc_html_e( 'Less than ( < )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
			<option value="greater_equal_to"><?php esc_html_e( 'Greater or Equal to ( >= )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
			<option value="greater_then"><?php esc_html_e( 'Greater than ( > )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
			<option value="not_in"><?php esc_html_e( 'Not Equal to ( != )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
		</select>
		<select class="select-condition">
			<option value="is_equal_to"><?php esc_html_e( 'Equal to ( = )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
			<option value="not_in"><?php esc_html_e( 'Not Equal to ( != )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
		</select>
	</div>
	<div class="default-country-box" style="display:none;">
		<?php echo wp_kses($this->wdpad_pro_get_country_list(),allowed_html_tags()); ?>
	</div>
	<div class="wdpad-main-table res-cl">
		<h2><?php esc_html_e( 'Fee Configuration', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></h2>
		<form method="POST" name="dpadfrm" action="">
			<input type="hidden" name="post_type" value="wc_dynamic_pricing">
			<input type="hidden" name="dpad_post_id" value="<?php echo esc_attr($paction_id) ?>">
			<table class="form-table table-outer product-fee-table">
				<tbody>
				<tr valign="top">
					<th class="titledesc" scope="row"><label for="dpad_settings_product_dpad_title"><?php esc_html_e( 'Discount Rule Title For Checkout',
								WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?><span class="required-star">*</span></label></th>
					<td class="forminp">
						<input type="text" name="dpad_settings_product_dpad_title" class="text-class" id="dpad_settings_product_dpad_title"
						       value="<?php echo isset( $dpad_title ) ? esc_attr($dpad_title) : ''; ?>" required="1"
						       placeholder="<?php esc_html_e( 'Enter product discount title', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
						<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
						<p class="description"
						   style="display:none;"><?php esc_html_e( 'This discount rule title is visible to the customer at the time of checkout.', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></p>
					</td>

				</tr>
				<tr valign="top">
					<th class="titledesc" scope="row">
						<label for="dpad_settings_select_dpad_type"><?php esc_html_e( 'Select Discount Type', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></label>
					</th>
					<td class="forminp">
						<select name="dpad_settings_select_dpad_type" id="dpad_settings_select_dpad_type" class="">
							<option value="fixed" <?php echo isset( $getFeesType ) && $getFeesType === 'fixed' ? 'selected="selected"' : '' ?>><?php esc_html_e( 'Fixed', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
							<option value="percentage" <?php echo isset( $getFeesType ) && $getFeesType === 'percentage' ? 'selected="selected"' : '' ?>><?php esc_html_e( 'Percentage', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
						</select>
						<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
						<p class="description"
						   style="display:none;"><?php esc_html_e( 'You can give discount on fixed price or percentage based.', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th class="titledesc" scope="row"><label
								for="dpad_settings_product_cost"><?php esc_html_e( 'Discount value', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?> <span
									class="required-star">*</span></label></th>
					<td class="forminp">
						<div class="product_cost_left_div">
							<input type="text" id="dpad_settings_product_cost" name="dpad_settings_product_cost" required="1" class="text-class" id="dpad_settings_product_cost"
							       value="<?php echo isset
							       ( $getFeesCost ) ? esc_attr($getFeesCost) : ''; ?>" placeholder="<?php echo esc_attr(get_woocommerce_currency_symbol()); ?>">
							<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
							<p class="description" style="display:none;">
								<?php 
								esc_html_e( 'If you select fixed discount type then : you have add fixed discount value. (Eg. 10, 20)'); 
								echo '<br/>';
                                esc_html_e( 'If you select percentage based discount type then : you have add percentage of discount (Eg. 10, 15.20)', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>
							</p>
						</div>
						<div class="product_cost_right_div">

							<div class="applyperqty-boxone">
								<label for="dpad_chk_qty_price"><?php esc_html_e( 'Apply Per Quantity', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></label>
								<input type="checkbox" name="dpad_chk_qty_price" id="dpad_chk_qty_price" class="chk_qty_price_class"
								       value="on" <?php checked( $getFeesPerQtyFlag, 'on' ); ?>>
								<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
								<p class="description"
								   style="display:none;"><?php esc_html_e( 'Apply this discount per quantity of products.', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></p>
							</div>

							<div class="applyperqty-boxtwo">
								<label for="apply_per_qty_type"><?php esc_html_e( 'Calculate Quantity Based On', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></label>
								<select name="dpad_per_qty" id="price_cartqty_based" class="chk_qty_price_class" id="apply_per_qty_type">
									<option value="qty_cart_based" <?php selected( $getFeesPerQty, 'qty_cart_based' ); ?>><?php esc_html_e( 'Cart Based', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
									<option value="qty_product_based" <?php selected( $getFeesPerQty, 'qty_product_based' ); ?>><?php esc_html_e( 'Product Based', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
								</select>
								<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
								<p class="description"
								   style="display:none;"><?php esc_html_e( 'If you want to apply the discount for each quantity - where quantity should calculated based on product/category/tag conditions, then select the "Product Based" option.');
								   echo '<br>'; 
								   esc_html_e( 'If you want to apply the discount for each quantity in the customer\'s cart, then select the "Cart Based" option.', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></p>
							</div>

							<?php
							$additionaldpad_desc = esc_html( 'You can add discount here to be charged for each additional quantity. E.g. if user has added 3 quantities and you have set discount=$10 and discount per additional quantity=$5, then total
 extra discount=$10+$5+$5=$20').'<br>'
							                           . esc_html('The quantity will be calculated based on the option chosen in the "Calculate Quantity Based On" above dropdown. That means, if you have chosen "Product Based" option - quantities will be calculated based on the products which are meeting the conditions set for this discount, and if they are more than 1, discount will be calculated considering only its additional quantities. e.g. 5 items in cart, and 3 are meeting the condition set, then additional discount of $5 will be charged on 2 quantities only, and not on 4 quantities.', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN );
							?>
							<div class="applyperqty-boxthree">
								<label for="extra_product_cost"><?php esc_html_e( 'Discount per Additional Quantity&nbsp;(' . get_woocommerce_currency_symbol() . ') ', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>
									<span class="required-star">*</span></label>
								<input type="number" name="extra_product_cost" class="text-class" id="extra_product_cost" required
								       value="<?php echo isset( $extraProductCost ) ? esc_attr($extraProductCost) : ''; ?>" placeholder="<?php echo esc_attr(get_woocommerce_currency_symbol()); ?>">
								<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
								<p class="description" style="display:none;"><?php echo wp_kses($additionaldpad_desc,allowed_html_tags()); ?></p>
							</div>

						</div>
					</td>
				</tr>
				<tr valign="top">
					<th class="titledesc" scope="row"><label
								for="dpad_settings_start_date"><?php esc_html_e( 'Start Date', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></label></th>
					<td class="forminp">
						<input type="text" name="dpad_settings_start_date" class="text-class" id="dpad_settings_start_date"
						       value="<?php echo isset( $getFeesStartDate ) ? esc_attr($getFeesStartDate) : ''; ?>"
						       placeholder="<?php esc_html_e( 'Select start date', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
						<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
						<p class="description"
						   style="display:none;"><?php esc_html_e( 'Select start date which date product discount rules will enable on website.', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th class="titledesc" scope="row"><label
								for="dpad_settings_end_date"><?php esc_html_e( 'End Date', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></label></th>
					<td class="forminp">
						<input type="text" name="dpad_settings_end_date" class="text-class" id="dpad_settings_end_date"
						       value="<?php echo isset( $getFeesEndDate ) ? esc_attr($getFeesEndDate) : ''; ?>"
						       placeholder="<?php esc_html_e( 'Select end date', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
						<span class="woocommerce_conditional_product_dpad_checkout_tab_descirtion"></span>
						<p class="description"
						   style="display:none;"><?php esc_html_e( 'Select ending date which date product discount rules will disable on website', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th class="titledesc" scope="row"><label for="onoffswitch"><?php esc_html_e( 'Status', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></label></th>
					<td class="forminp">
						<label class="switch">
							<input type="checkbox" name="dpad_settings_status" value="on" <?php echo ( isset( $getFeesStatus ) && $getFeesStatus === 'off' ) ? '' : 'checked'; ?>>
							<div class="slider round"></div>
						</label>
					</td>
				</tr>
				</tbody>
			</table>
			<div class="sub-title">
				<h2><?php esc_html_e( 'Discount Rules for checkout', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></h2>
				<div class="tap"><a id="fee-add-field" class="button button-primary button-large"
				                    href="javascript:;"><?php esc_html_e( '+ Add Row', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></a></div>
			</div>
			<div class="tap">
				<table id="tbl-product-fee" class="tbl_product_fee table-outer tap-cas form-table product-fee-table">
					<tbody>
					<?php
					if ( isset( $productFeesArray ) && ! empty( $productFeesArray ) ) {
						$i = 2;
						foreach ( $productFeesArray as $key => $productdpad ) {
							$dpad_conditions = isset( $productdpad['product_dpad_conditions_condition'] ) ? $productdpad['product_dpad_conditions_condition'] : '';
							$condition_is    = isset( $productdpad['product_dpad_conditions_is'] ) ? $productdpad['product_dpad_conditions_is'] : '';
							$condtion_value  = isset( $productdpad['product_dpad_conditions_values'] ) ? $productdpad['product_dpad_conditions_values'] : array();
							if ( wcdrfc_fs()->is__premium_only() ) {
								if ( wcdrfc_fs()->can_use_premium_code() ) {
									?>
									<tr id="row_<?php echo esc_attr($i); ?>" valign="top">
										<th class="titledesc th_product_dpad_conditions_condition" scope="row">
											<select rel-id="<?php echo esc_attr($i); ?>" id="product_dpad_conditions_condition_<?php echo esc_attr($i); ?>"
											        name="dpad[product_dpad_conditions_condition][]"
											        id="product_dpad_conditions_condition" class="product_dpad_conditions_condition">
												<optgroup label="<?php esc_html_e( 'Location Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
													<option value="country" <?php echo ( $dpad_conditions === 'country' ) ? 'selected' : '' ?>><?php esc_html_e( 'Country', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="state" <?php echo ( $dpad_conditions === 'state' ) ? 'selected' : '' ?>><?php esc_html_e( 'State', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="postcode" <?php echo ( $dpad_conditions === 'postcode' ) ? 'selected' : '' ?>><?php esc_html_e( 'Postcode', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="zone" <?php echo ( $dpad_conditions === 'zone' ) ? 'selected' : '' ?>><?php esc_html_e( 'Zone', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												</optgroup>
												<optgroup label="<?php esc_html_e( 'Product Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
													<option value="product" <?php echo ( $dpad_conditions === 'product' ) ? 'selected' : '' ?>><?php esc_html_e( 'Product', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="variableproduct" <?php echo ( $dpad_conditions === 'variableproduct' ) ? 'selected' : '' ?>><?php esc_html_e( 'Variable Product', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="category" <?php echo ( $dpad_conditions === 'category' ) ? 'selected' : '' ?>><?php esc_html_e( 'Category', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="tag" <?php echo ( $dpad_conditions === 'tag' ) ? 'selected' : '' ?>><?php esc_html_e( 'Tag', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												</optgroup>
												<optgroup label="<?php esc_html_e( 'User Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
													<option value="user" <?php echo ( $dpad_conditions === 'user' ) ? 'selected' : '' ?>><?php esc_html_e( 'User', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="user_role" <?php echo ( $dpad_conditions === 'user_role' ) ? 'selected' : '' ?>><?php esc_html_e( 'User Role', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												</optgroup>
												<optgroup label="<?php esc_html_e( 'Cart Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
													<?php
													$currency_symbol = get_woocommerce_currency_symbol();
													$currency_symbol = ! empty( $currency_symbol ) ? '(' . $currency_symbol . ')' : '';

													$weight_unit = get_option( 'woocommerce_weight_unit' );
													$weight_unit = ! empty( $weight_unit ) ? '(' . $weight_unit . ')' : '';
													?>
													<option value="cart_total" <?php echo ( $dpad_conditions === 'cart_total' ) ? 'selected' : '' ?>><?php esc_html_e( 'Cart Subtotal (Before Discount) ', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?><?php echo esc_html($currency_symbol); ?></option>
													<option value="cart_totalafter" <?php echo ( $dpad_conditions === 'cart_totalafter' ) ? 'selected' : '' ?>><?php esc_html_e( 'Cart Subtotal (After Discount) ', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?><?php echo esc_html($currency_symbol); ?></option>
													<option value="quantity" <?php echo ( $dpad_conditions === 'quantity' ) ? 'selected' : '' ?>><?php esc_html_e( 'Quantity', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="weight" <?php echo ( $dpad_conditions === 'weight' ) ? 'selected' : '' ?>><?php esc_html_e( 'Weight ', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?><?php echo esc_html($weight_unit); ?></option>
													<option value="coupon" <?php echo ( $dpad_conditions === 'coupon' ) ? 'selected' : '' ?>><?php esc_html_e( 'Coupon', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="shipping_class" <?php echo ( $dpad_conditions === 'shipping_class' ) ? 'selected' : '' ?>><?php esc_html_e( 'Shipping Class', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												</optgroup>
												<optgroup label="<?php esc_html_e( 'Payment Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
													<option value="payment" <?php echo ( $dpad_conditions === 'payment' ) ? 'selected' : '' ?>><?php esc_html_e( 'Payment Gateway', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												</optgroup>
												<optgroup label="<?php esc_html_e( 'Shipping Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
													<option value="shipping_method" <?php echo ( $dpad_conditions === 'shipping_method' ) ? 'selected' : '' ?>><?php esc_html_e( 'Shipping Method', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												</optgroup>
											</select>
										</th>
										<td class="select_condition_for_in_notin">
											<?php if ( $dpad_conditions === 'cart_total' || $dpad_conditions === 'cart_totalafter' || $dpad_conditions === 'quantity' || $dpad_conditions === 'weight' ) { ?>
												<select name="dpad[product_dpad_conditions_is][]" class="product_dpad_conditions_is_<?php echo esc_attr($i); ?>">
													<option value="is_equal_to" <?php echo ( $condition_is === 'is_equal_to' ) ? 'selected' : '' ?>><?php esc_html_e( 'Equal to ( = )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="less_equal_to" <?php echo ( $condition_is === 'less_equal_to' ) ? 'selected' : '' ?>><?php esc_html_e( 'Less or Equal to ( <= )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="less_then" <?php echo ( $condition_is === 'less_then' ) ? 'selected' : '' ?>><?php esc_html_e( 'Less than ( < )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="greater_equal_to" <?php echo ( $condition_is === 'greater_equal_to' ) ? 'selected' : '' ?>><?php esc_html_e( 'Greater or Equal to ( >= )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="greater_then" <?php echo ( $condition_is === 'greater_then' ) ? 'selected' : '' ?>><?php esc_html_e( 'Greater than ( > )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="not_in" <?php echo ( $condition_is === 'not_in' ) ? 'selected' : '' ?>><?php esc_html_e( 'Not Equal to ( != )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												</select>
											<?php } else { ?>
												<select name="dpad[product_dpad_conditions_is][]" class="product_dpad_conditions_is_<?php echo esc_attr($i); ?>">
													<option value="is_equal_to" <?php echo ( $condition_is === 'is_equal_to' ) ? 'selected' : '' ?>><?php esc_html_e( 'Equal to ( = )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
													<option value="not_in" <?php echo ( $condition_is === 'not_in' ) ? 'selected' : '' ?>><?php esc_html_e( 'Not Equal to ( != )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?> </option>
												</select>
											<?php } ?>
										</td>
										<td class="condition-value" id="column_<?php echo esc_attr($i); ?>">
											<?php
											$html = '';
											if ( $dpad_conditions === 'country' ) {
												$html .= $this->wdpad_pro_get_country_list( $i, $condtion_value );
											} elseif ( $dpad_conditions === 'state' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_states_list__premium_only( $i, $condtion_value );
													}
												}
											} elseif ( $dpad_conditions === 'postcode' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= '<textarea name = "dpad[product_dpad_conditions_values][value_' . $i . ']">' . $condtion_value . '</textarea>';
													}
												}
											} elseif ( $dpad_conditions === 'zone' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_zones_list__premium_only( $i, $condtion_value );
													}
												}
											} elseif ( $dpad_conditions === 'product' ) {
												$html .= $this->wdpad_pro_get_product_list( $i, $condtion_value, 'edit' );
											} elseif ( $dpad_conditions === 'variableproduct' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_varible_product_list__premium_only( $i, $condtion_value, 'edit' );
													}
												}
											} elseif ( $dpad_conditions === 'category' ) {
												$html .= $this->wdpad_pro_get_category_list( $i, $condtion_value );
											} elseif ( $dpad_conditions === 'tag' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_tag_list__premium_only( $i, $condtion_value );
													}
												}
											} elseif ( $dpad_conditions === 'user' ) {
												$html .= $this->wdpad_pro_get_user_list( $i, $condtion_value );
											} elseif ( $dpad_conditions === 'user_role' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_user_role_list__premium_only( $i, $condtion_value );
													}
												}
											} elseif ( $dpad_conditions === 'cart_total' ) {
												$html .= '<input type = "number" min="0" name = "dpad[product_dpad_conditions_values][value_' . $i . ']" id = "product_dpad_conditions_values" class = "product_dpad_conditions_values" value = "' . $condtion_value . '">';
											} elseif ( $dpad_conditions === 'cart_totalafter' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= '<input type="number" min="0" name="dpad[product_dpad_conditions_values][value_' . $i . ']" id="product_dpad_conditions_values" class="product_dpad_conditions_values" value="' . $condtion_value . '">';
													}
												}
											} elseif ( $dpad_conditions === 'quantity' ) {
												$html .= '<input type = "number"  min="0"  name = "dpad[product_dpad_conditions_values][value_' . $i . ']" id = "product_dpad_conditions_values" class = "product_dpad_conditions_values" value = "' . $condtion_value . '">';
											} elseif ( $dpad_conditions === 'weight' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= '<input type = "number" min="0" name = "dpad[product_dpad_conditions_values][value_' . $i . ']" id = "product_dpad_conditions_values" class = "product_dpad_conditions_values" value = "' . $condtion_value . '">';
													}
												}
											} elseif ( $dpad_conditions === 'coupon' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_coupon_list__premium_only( $i, $condtion_value );
													}
												}
											} elseif ( $dpad_conditions === 'shipping_class' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_advance_flat_rate_class__premium_only( $i, $condtion_value );
													}
												}
											} elseif ( $dpad_conditions === 'payment' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_payment_methods__premium_only( $i, $condtion_value );
													}
												}
											} elseif ( $dpad_conditions === 'shipping_method' ) {
												if ( wcdrfc_fs()->is__premium_only() ) {
													if ( wcdrfc_fs()->can_use_premium_code() ) {
														$html .= $this->wdpad_pro_get_active_shipping_methods__premium_only( $i, $condtion_value );
													}
												}
											}
											echo wp_kses($html,allowed_html_tags());
											?>
											<input type="hidden" name="condition_key[<?php echo 'value_' . esc_attr($i); ?>]" value="">
										</td>
										<td><a id="fee-delete-field" rel-id="<?php echo esc_attr($i); ?>" class="delete-row" href="javascript:;" title="Delete"><i
														class="fa fa-trash"></i></a>
										</td>
									</tr>
									<?php
								}
							} else { ?>
								<tr id="row_<?php echo esc_attr($i); ?>" valign="top">
									<th class="titledesc th_product_dpad_conditions_condition" scope="row">
										<select rel-id="<?php echo esc_attr($i); ?>" id="product_dpad_conditions_condition_<?php echo esc_attr($i); ?>" name="dpad[product_dpad_conditions_condition][]"
										        id="product_dpad_conditions_condition" class="product_dpad_conditions_condition">
											<optgroup label="<?php esc_html_e( 'Location Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
												<option value="country" <?php echo ( $dpad_conditions === 'country' ) ? 'selected' : '' ?>><?php esc_html_e( 'Country', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="state" <?php echo ( $dpad_conditions === 'state' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'State (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="postcode" <?php echo ( $dpad_conditions === 'postcode' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Postcode (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="zone" <?php echo ( $dpad_conditions === 'zone' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Zone (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Product Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
												<option value="product" <?php echo ( $dpad_conditions === 'product' ) ? 'selected' : '' ?>><?php esc_html_e( 'Product', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="variableproduct" <?php echo ( $dpad_conditions === 'variableproduct' ) ? 'selected' : '' ?> disabled><?php esc_html_e( 'Variable 
                                            Product (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="category" <?php echo ( $dpad_conditions === 'category' ) ? 'selected' : '' ?>><?php esc_html_e( 'Category', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="tag" <?php echo ( $dpad_conditions === 'tag' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Tag (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'User Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
												<option value="user" <?php echo ( $dpad_conditions === 'user' ) ? 'selected' : '' ?>><?php esc_html_e( 'User', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="user_role" <?php echo ( $dpad_conditions === 'user_role' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'User Role (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Cart Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
												<?php
												$currency_symbol = get_woocommerce_currency_symbol();
												$currency_symbol = ! empty( $currency_symbol ) ? '(' . $currency_symbol . ')' : '';

												$weight_unit = get_option( 'woocommerce_weight_unit' );
												$weight_unit = ! empty( $weight_unit ) ? '(' . $weight_unit . ')' : '';
												?>
												<option value="cart_total" <?php echo ( $dpad_conditions === 'cart_total' ) ? 'selected' : '' ?>><?php esc_html_e( 'Cart Subtotal', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="quantity" <?php echo ( $dpad_conditions === 'quantity' ) ? 'selected' : '' ?>><?php esc_html_e( 'Quantity', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="weight" <?php echo ( $dpad_conditions === 'weight' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Weight (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?><?php echo esc_html($weight_unit); ?></option>
												<option value="coupon" <?php echo ( $dpad_conditions === 'coupon' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Coupon (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="shipping_class" <?php echo ( $dpad_conditions === 'shipping_class' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Shipping Class (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Payment Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
												<option value="payment" <?php echo ( $dpad_conditions === 'payment' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Payment Gateway (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Shipping Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
												<option value="shipping_method" <?php echo ( $dpad_conditions === 'shipping_method' ) ? 'selected' : '' ?>
												        disabled><?php esc_html_e( 'Shipping Method (Available in Pro Version)',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
											</optgroup>
										</select>
									</th>
									<td class="select_condition_for_in_notin">
										<?php if ( 'cart_total' === $dpad_conditions || 'cart_totalafter' === $dpad_conditions || 'quantity' === $dpad_conditions || 'weight' ===
										                                                                                                                             $dpad_conditions ) { ?>
											<select name="dpad[product_dpad_conditions_is][]" class="product_dpad_conditions_is_<?php echo esc_attr($i); ?>">
												<option value="is_equal_to" <?php echo ( 'is_equal_to' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Equal to ( = )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="less_equal_to" <?php echo ( 'less_equal_to' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Less or Equal to ( <= )',
														'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="less_then" <?php echo ( 'less_then' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Less than ( < )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="greater_equal_to" <?php echo ( 'greater_equal_to' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Greater or Equal to ( >= )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="greater_then" <?php echo ( 'greater_then' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Greater than ( > )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="not_in" <?php echo ( 'not_in' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Not Equal to ( != )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											</select>
										<?php } else { ?>
											<select name="dpad[product_dpad_conditions_is][]" class="product_dpad_conditions_is_<?php echo esc_attr($i); ?>">
												<option value="is_equal_to" <?php echo ( 'is_equal_to' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Equal to ( = )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
												<option value="not_in" <?php echo ( 'not_in' === $condition_is ) ? 'selected' : '' ?>><?php esc_html_e( 'Not Equal to ( != )', 'woo-conditional-discount-rules-for-checkout' ); ?> </option>
											</select>
										<?php } ?>
									</td>
									<td class="condition-value" id="column_<?php echo esc_attr($i); ?>">
										<?php
										$html = '';
										if ( 'country' === $dpad_conditions ) {
											$html .= $this->wdpad_pro_get_country_list( $i, $condtion_value );
										} elseif ( 'product' === $dpad_conditions ) {
											$html .= $this->wdpad_pro_get_product_list( $i, $condtion_value, 'edit' );
										} elseif ( 'category' === $dpad_conditions ) {
											$html .= $this->wdpad_pro_get_category_list( $i, $condtion_value );
										} elseif ( 'user' === $dpad_conditions ) {
											$html .= $this->wdpad_pro_get_user_list( $i, $condtion_value );
										} elseif ( 'cart_total' === $dpad_conditions ) {
											$html .= '<input type = "number" min="0" name = "dpad[product_dpad_conditions_values][value_' . $i . ']" id = "product_dpad_conditions_values" class = "product_dpad_conditions_values" value = "' . $condtion_value . '">';
										} elseif ( 'quantity' === $dpad_conditions ) {
											$html .= '<input type = "number" min="0" name = "dpad[product_dpad_conditions_values][value_' . esc_attr($i) . ']" id = "product_dpad_conditions_values" class = "product_dpad_conditions_values" value = "' . $condtion_value . '">';
										}
										echo wp_kses($html,allowed_html_tags());										
										?>
										<input type="hidden" name="condition_key[<?php echo 'value_' . esc_attr($i); ?>]" value="">
									</td>
									<td><a id="fee-delete-field" rel-id="<?php echo esc_attr($i); ?>" class="delete-row" href="javascript:;" title="Delete"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php }
							$i ++;
						}
						?>
						<?php
					} else {
						$i = 1;
						if ( wcdrfc_fs()->is__premium_only() ) {
							if ( wcdrfc_fs()->can_use_premium_code() ) {
								?>
								<tr id="row_1" valign="top">
									<th class="titledesc th_product_dpad_conditions_condition" scope="row">
										<select rel-id="1" id="product_dpad_conditions_condition_1" name="dpad[product_dpad_conditions_condition][]"
										        id="product_dpad_conditions_condition"
										        class="product_dpad_conditions_condition">
											<optgroup label="<?php esc_html_e( 'Location Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
												<option value="country"><?php esc_html_e( 'Country', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="state"><?php esc_html_e( 'State', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="postcode"><?php esc_html_e( 'Postcode', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="zone"><?php esc_html_e( 'Zone', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Product Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
												<option value="product"><?php esc_html_e( 'Product', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="variableproduct"><?php esc_html_e( 'Variable Product', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="category"><?php esc_html_e( 'Category', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="tag"><?php esc_html_e( 'Tag', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'User Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
												<option value="user"><?php esc_html_e( 'User', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="user_role"><?php esc_html_e( 'User Role', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Cart Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
												<?php
												$currency_symbol = get_woocommerce_currency_symbol();
												$currency_symbol = ! empty( $currency_symbol ) ? '(' . $currency_symbol . ')' : '';

												$weight_unit = get_option( 'woocommerce_weight_unit' );
												$weight_unit = ! empty( $weight_unit ) ? '(' . $weight_unit . ')' : '';
												?>
												<option value="cart_total"><?php esc_html_e( 'Cart Subtotal', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="quantity"><?php esc_html_e( 'Quantity', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="weight"><?php esc_html_e( 'Weight', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?><?php echo esc_html($weight_unit);; ?></option>
												<option value="coupon"><?php esc_html_e( 'Coupon', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
												<option value="shipping_class"><?php esc_html_e( 'Shipping Class', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Payment Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
												<option value="payment"><?php esc_html_e( 'Payment Gateway', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
											</optgroup>
											<optgroup label="<?php esc_html_e( 'Shipping Specific', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?>">
												<option value="shipping_method"><?php esc_html_e( 'Shipping Method', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
											</optgroup>
										</select>
									</td>
									<td class="select_condition_for_in_notin">
										<select name="dpad[product_dpad_conditions_is][]" class="product_dpad_conditions_is product_dpad_conditions_is_1">
											<option value="is_equal_to"><?php esc_html_e( 'Equal to ( = )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
											<option value="not_in"><?php esc_html_e( 'Not Equal to ( != )', WOOCOMMERCE_CONDITIONAL_DISCOUNT_FOR_CHECKOUT_PRO_TEXT_DOMAIN ); ?></option>
										</select>
									</td>

									<td id="column_1" class="condition-value">
										<?php echo wp_kses($this->wdpad_pro_get_country_list( 1 ),allowed_html_tags()); ?>
										<input type="hidden" name="condition_key[value_1][]" value="">
									</td>
								</tr>
								<?php
							}
						} else { ?>
							<tr id="row_1" valign="top">
								<th class="titledesc th_product_dpad_conditions_condition" scope="row">
									<select rel-id="1" id="product_dpad_conditions_condition_1" name="dpad[product_dpad_conditions_condition][]"
									        id="product_dpad_conditions_condition"
									        class="product_dpad_conditions_condition">
										<optgroup label="<?php esc_html_e( 'Location Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
											<option value="country"><?php esc_html_e( 'Country', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="state"
											        disabled><?php esc_html_e( 'State (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="postcode"
											        disabled><?php esc_html_e( 'Postcode (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="zone"
											        disabled><?php esc_html_e( 'Zone (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
										</optgroup>
										<optgroup label="<?php esc_html_e( 'Product Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
											<option value="product"><?php esc_html_e( 'Product', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="variableproduct" disabled><?php esc_html_e( 'Variable Product (Available in Pro Version)',
													'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="category"><?php esc_html_e( 'Category', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="tag"
											        disabled><?php esc_html_e( 'Tag (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
										</optgroup>
										<optgroup label="<?php esc_html_e( 'User Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
											<option value="user"><?php esc_html_e( 'User', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="user_role"
											        disabled><?php esc_html_e( 'User Role (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
										</optgroup>
										<optgroup label="<?php esc_html_e( 'Cart Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
											<?php
											$currency_symbol = get_woocommerce_currency_symbol();
											$currency_symbol = ! empty( $currency_symbol ) ? '(' . $currency_symbol . ')' : '';

											$weight_unit = get_option( 'woocommerce_weight_unit' );
											$weight_unit = ! empty( $weight_unit ) ? '(' . $weight_unit . ')' : '';
											?>
											<option value="cart_total"><?php esc_html_e( 'Cart Subtotal', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="quantity"><?php esc_html_e( 'Quantity', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="weight"
											        disabled><?php esc_html_e( 'Weight (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?><?php echo esc_html($weight_unit);
												?></option>
											<option value="coupon"
											        disabled><?php esc_html_e( 'Coupon (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
											<option value="shipping_class"
											        disabled><?php esc_html_e( 'Shipping Class (Available in Pro Version)', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
										</optgroup>
										<optgroup label="<?php esc_html_e( 'Payment Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
											<option value="payment" disabled><?php esc_html_e( 'Payment Gateway (Available in Pro Version)',
													'woo-conditional-discount-rules-for-checkout' ); ?></option>
										</optgroup>
										<optgroup label="<?php esc_html_e( 'Shipping Specific', 'woo-conditional-discount-rules-for-checkout' ); ?>">
											<option value="shipping_method" disabled><?php esc_html_e( 'Shipping Method (Available in Pro Version)',
													'woo-conditional-discount-rules-for-checkout' ); ?></option>
										</optgroup>
									</select>
								</td>
								<td class="select_condition_for_in_notin">
									<select name="dpad[product_dpad_conditions_is][]" class="product_dpad_conditions_is product_dpad_conditions_is_1">
										<option value="is_equal_to"><?php esc_html_e( 'Equal to ( = )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
										<option value="not_in"><?php esc_html_e( 'Not Equal to ( != )', 'woo-conditional-discount-rules-for-checkout' ); ?></option>
									</select>
								</td>
								<td id="column_1" class="condition-value">
									<?php echo wp_kses($this->wdpad_pro_get_country_list( 1 ),allowed_html_tags()); ?>
									<input type="hidden" name="condition_key[value_1][]" value="">
								</td>
							</tr>
						<?php }
					} ?>
					</tbody>
				</table>
				<input type="hidden" name="total_row" id="total_row" value="<?php echo esc_attr($i); ?>">
			</div>
			<p class="submit"><input type="submit" name="submitFee"  class="submitFee button button-primary button-large" value="<?php echo esc_attr($btnValue); ?>"></p>
		</form>
	</div>
<?php require_once(plugin_dir_path( __FILE__ ).'header/plugin-sidebar.php' );
?>
