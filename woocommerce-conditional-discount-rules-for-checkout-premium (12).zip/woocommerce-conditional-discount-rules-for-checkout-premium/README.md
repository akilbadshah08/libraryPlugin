# theDotstore-woocommerce-conditional-discount-rules-for-checkout
Create any type of woocommerce conditional discount such as Bulk discounts, Country based Discount, cart discounts, special offers, user role-based discounts and more.
